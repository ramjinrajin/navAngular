export class Student
{
  code:string;
  name :string;
  division:string;
  gender:string;
  dateOfBirth:string;
}