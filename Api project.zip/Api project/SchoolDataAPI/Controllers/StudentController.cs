﻿using Newtonsoft.Json;
using SchoolDataAPI.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;


namespace SchoolDataAPI.Controllers
{
    [RoutePrefix("api/Student")]
    public class StudentController : ApiController
    {
         [HttpGet]
        public IEnumerable<Student> Get()
        {
           // System.Threading.Thread.Sleep(3000);
            using (SchoolDbEntities entity = new SchoolDbEntities())
            {
                return entity.Students.ToList();
            }
        }

        [HttpGet]
        public Student GetStudentByCode(string code)
        {
            // System.Threading.Thread.Sleep(3000);
            using (SchoolDbEntities entity = new SchoolDbEntities())
            {
                return entity.Students.Where(x => x.code == code).First();
            }
        }


        [HttpPost]
        public HttpResponseMessage Create(Student value)
        {
            using (SchoolDbEntities entity = new SchoolDbEntities())
            {
                entity.Students.Add(value);
                entity.SaveChanges();
            }
            return ToJson(value);
        }

        [HttpPost]
        [Route("Update")]
        public HttpResponseMessage UpdateStudentData(Student value)
        {
            using (SchoolDbEntities entity = new SchoolDbEntities())
            {
                var data = entity.Students.Where(x => x.code == value.code).First();
                entity.Students.Remove(data);
                entity.Students.Add(value);
                entity.SaveChanges();

            }
            return ToJson(value);
        }

        [HttpGet]
        [Route("Delete")]
        public HttpResponseMessage DeleteStudent(string code)
        {
            using (SchoolDbEntities entity = new SchoolDbEntities())
            {
                var student = entity.Students.Where(x => x.code == code).First();
                entity.Students.Remove(student);
                entity.SaveChanges();
                
            }
            return ToJson(code);

        }
        protected HttpResponseMessage ToJson(dynamic obj)
        {
            var response = Request.CreateResponse(HttpStatusCode.OK);
            response.Content = new StringContent(JsonConvert.SerializeObject(obj), System.Text.Encoding.UTF8, "application/json");
            return response;
        }

        //public Student Get(string code)
        //{
        //    using (SchoolDbEntities entity = new SchoolDbEntities())
        //    {
        //        return entity.Students.Where(x=>x.code==code).First();
        //    }
        //}
    }
}